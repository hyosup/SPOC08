sap.ui.define([
    "sap/m/Dialog",
    "sap/m/DialogRenderer",
    "sap/m/VBox",
    "sap/m/ComboBox",
    "sap/m/CheckBox",
    "sap/m/Button",
    "sap/ui/core/ListItem",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Parent, ParentRenderer, VBox, ComboBox, CheckBox, Button, ListItem, MessageBox, MessageToast){
    "use strict";

    const CustomDialog = Parent.extend("dialog.RejectAllDialog", {

        renderer: ParentRenderer,

        constructor: function(){
            Parent.apply(this, arguments);

            let oBox = new VBox({
                items: [
                    new CheckBox({
                        text: "거절 사유",
                        selected: {
                            path: '/hasRejectReason'
                        }
                    }),
                    this.oRejectReasonCombo = new ComboBox({
                        id: "rejectAllDialog_reason",
                        items: {
                            path: 'valueHelps>/rejectReasons',
                            templateShareable:true,
                            template: new ListItem({
                                key: "{valueHelps>value}",
                                text: "{valueHelps>text}"
                            })
                        },
                        selectedKey: {
                            path: "/rejectReason"
                        },
                        enabled: "{= ${/hasRejectReason} ? true : false }",
                        required: "{= ${/hasRejectReason} ? true : false }"
                    })
                ]
            });
            oBox.addStyleClass("sapUiMediumMargin");
            this.addContent(oBox);

            // this.setTitle("거절 사유");
            this.setBeginButton(new Button({
                type: "Emphasized",
                text: "Apply",
                press: this.handleApplyPress.bind(this)
            }));
            this.setEndButton(new Button({
                type: "Transparent",
                text: "Cancel",
                press: this.handleCancelPress.bind(this)
            }));

        },

        handleApplyPress: function(){
            const oModel = this.getModel();
            if(oModel.getProperty("/hasRejectReason") === true && !oModel.getProperty("/rejectReason")){
                this.oRejectReasonCombo.setValueState("Error");
                this.oRejectReasonCombo.setValueStateText("거절 사유를 선택 하세요.");
                return;
            }else {
                this.oRejectReasonCombo.setValueState("None");
                this.getModel("body").callFunction("/reject_all", {
                    method : 'POST',
                    urlParameters : {
                        audat: oModel.getProperty("/audat"),
                        auart: oModel.getProperty("/auart"),
                        vbeln: oModel.getProperty("/vbeln"),
                        Abgru: oModel.getProperty("/rejectReason")
                    },
                    success : function(data) {
                        MessageToast.show("오더를 거절 처리 하였습니다.");
                        this.close();
                    }.bind(this),
                    error : function(data) {
                        MessageBox.alert("오더 거절 중 오류가 발생 하였습니다.");
                    }
                });  
                ///sap/opu/odata/sap/ZUI_POC08_ODATA/reject_all?audat=datetime'2021-01-15T00%3A00%3A00'&auart='OR'&vbeln='3974'&Abgru='00'
            }
            this.close();
        },

        handleCancelPress: function(){
            this.close();
        }

    });

    return CustomDialog;
});
