sap.ui.define([
    "sap/m/Dialog",
    "sap/m/DialogRenderer",
    "sap/m/VBox",
    "sap/m/DatePicker",
    "sap/m/Button",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Parent, ParentRenderer, VBox, DatePicker, Button, MessageBox, MessageToast){
    "use strict";

    const CustomDialog = Parent.extend("dialog.RePricingDialog", {

        renderer: ParentRenderer,

        constructor: function(){
            Parent.apply(this, arguments);

            const oBox = new VBox({
                items: [
                    new DatePicker({
                        value: {
                            type: "sap.ui.model.type.Date",
                            path: "/date",
                            format: "yyyy-MM-dd"
                        },
                        displayFormat: "yyyy-MM-dd"
                    })
                ]
            });
            oBox.addStyleClass("sapUiMediumMargin");
            this.addContent(oBox);

            // this.setTitle("가격기준일 입력");
            this.setBeginButton(new Button({
                type: "Emphasized",
                text: "Apply",
                press: this.handleApplyPress.bind(this)
            }));
            this.setEndButton(new Button({
                type: "Transparent",
                text: "Cancel",
                press: this.handleCancelPress.bind(this)
            }));

        },

        handleApplyPress: function(){
            let oModel = this.getModel();
            this.getModel("body").callFunction("/re_pricing", {
                method : 'POST',
                urlParameters : {
                    audat: oModel.getProperty("/audat"),
                    auart: oModel.getProperty("/auart"),
                    vbeln: oModel.getProperty("/vbeln"),
                    Prsdt: oModel.getProperty("/date")
                },
                success : function(data) {
                    MessageToast.show("가격을 재 설정 하였습니다.");
                    this.close();
                }.bind(this),
                error : function(data) {
                    MessageBox.alert("가격 재 설정 중 오류가 발생 하였습니다.");
                }
            });  
            ///sap/opu/odata/sap/ZUI_POC08_ODATA/re_pricing?audat=datetime'2021-01-15T00%3A00%3A00'&auart='OR'&vbeln='3974'&Prsdt=datetime'2022-11-16T00%3A00%3A00'
        },

        handleCancelPress: function(){
            this.close();
        }

    });

    return CustomDialog;
});
