sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "../data/data",
    "../custom/RePricingDialog",
    "../custom/RejectAllDialog",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, valueHelpData, RePricingDialog, RejectAllDialog, MessageToast, Filter, FilterOperator) {
    "use strict";

    return BaseController.extend("com.mdpert.lgerppocfs1.controller.View1", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called when the worklist controller is instantiated.
         * @public
         */
        onInit : function () {
            var oViewModel, oValueHelpModel, oCustomViewModel;

            // keeps the search state
            this._aTableSearchState = [];

            // Model used to manipulate control states
            oViewModel = new JSONModel({
                headerExpanded: true,
                worklistTableTitle : this.getResourceBundle().getText("worklistTableTitle"),
                shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
                shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
                tableNoDataText : this.getResourceBundle().getText("tableNoDataText")
            });

            oCustomViewModel = new JSONModel({
                hasRejectReason: true,
                rejectReason: null
            })

            oValueHelpModel = new JSONModel(valueHelpData);

            this.setModel(oViewModel, "worklistView");
            this.setModel(oValueHelpModel, "valueHelps");
            this.setModel(oCustomViewModel, "customView");


            this.oRePricingDialog = new RePricingDialog();
            this.oRePricingDialog.setTitle(this.getResourceBundle().getText("dialog_reprice_title"));
            this.oRePricingDialog.setModel(this.getModel("customView"));
            this.oRePricingDialog.setModel(this.getOwnerComponent().getModel(), "body");

            this.oRejectReasonDiaog = new RejectAllDialog();
            this.oRejectReasonDiaog.setTitle(this.getResourceBundle().getText("dialog_rejectall_title"));
            this.oRejectReasonDiaog.setModel(this.getModel("customView"));
            this.oRejectReasonDiaog.setModel(this.getModel("valueHelps"), "valueHelps");
            this.oRejectReasonDiaog.setModel(this.getOwnerComponent().getModel(), "body");
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        onPriceModificationButtonPress: function(oEvent){
            let oModel = this.getModel("customView"),
                oTable = this.getView().byId("smartTable").getTable(),
                nIndex = oTable.getSelectedIndex();
            if(nIndex < 0){
                MessageToast.show("장기미결 오더를 선택 하세요. ");
                return;
            }
            let oContext = oTable.getBinding().getContexts()[nIndex],
                oData = this.getModel().getProperty(oContext.getPath())
            oModel.setProperty("/audat", oData.audat);
            oModel.setProperty("/auart", oData.auart);
            oModel.setProperty("/vbeln", oData.vbeln);
            oModel.setProperty("/date", new Date());
            this.oRePricingDialog.open();
        },

        onRejectAllButtonPress: function(){
            let oModel = this.getModel("customView"),
                oTable = this.getView().byId("smartTable").getTable(),
                nIndex = oTable.getSelectedIndex();
            if(nIndex < 0){
                MessageToast.show("장기미결 오더를 선택 하세요. ");
                return;
            }
            let oContext = oTable.getBinding().getContexts()[nIndex],
                oData = this.getModel().getProperty(oContext.getPath())
            oModel.setProperty("/audat", oData.audat);
            oModel.setProperty("/auart", oData.auart);
            oModel.setProperty("/vbeln", oData.vbeln);
            oModel.setProperty("/hasRejectReason", true);
            oModel.setProperty("/rejectReason", "");
            this.oRejectReasonDiaog.open();
        }
        
        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        
    });
});
