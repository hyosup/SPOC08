sap.ui.define([], function () {
    "use strict";

    return {
        auarts : [
            {value: "CA", text: "CA"},
            {value: "CBAR", text: "CBAR"},
            {value: "CBFD", text: "CBFD"},
            {value: "CCIS", text: "CCIS"},
            {value: "CCFU", text: "CCFU"},
            {value: "CCRE", text: "CCRE"},
            {value: "GA2", text: "GA2"},
            {value: "OR", text: "OR"},
            {value: "QT", text: "QT"},
            {value: "RK", text: "RK"},
            {value: "SRVO", text: "SRVO"},
            {value: "SD2", text: "SD2"}
        ],
        rejectReasons: [
            {value: "00", text: "영업)입력오류"},
            {value: "01", text: "영업)여신한도초과"},
            {value: "02", text: "영업)고객 요청일 불만족(수량,납기)"},
            {value: "03", text: "영업)고객요청에 의한 주문 취소"},
            {value: "04", text: "영업)고객요청에 의한 주문제품 변경"},
            {value: "05", text: "영업)고객 요청에 의한 품질 불만"},
            {value: "06", text: "영업)고객요청에 의한 생산계획 변경"},
            {value: "07", text: "영업)중복주문에 의한 주문 취소"},
            {value: "09", text: "영업)e-bIZ에 의한 주문 취소"},
            {value: "10", text: "영업)영업요청에 의해 주문 확정 보류"}

        ]
    };

});